<?php
	include 'header.php';
?>

 <div class="main">
    <div class="content">
    	<div class="support" align="left">
  			<div class="support_desc">
  				<h3>Live Support</h3>
  				<p><span>24 hours | 7 days a week | 365 days a year &nbsp;&nbsp; Live Technical Support</span></p>
  				<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
  			</div>
  				<img src="images/contact.png" alt="" />
  			<div class="clear"></div>
  		</div>
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Contact Us</h2>
					   <!-- <form>
					    	<div>
						    	<span><label>NAME</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						     	<span><label>MOBILE.NO</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						    	<span><label>SUBJECT</label></span>
						    	<span><textarea> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="SUBMIT"></span>
						  </div>
					    </form>-->
				  </div>
  				</div>
				<div class="col span_1_of_3">
					<div class="contact_info">
    	 				<h2>Find Us Here</h2>
					    	  <div class="map">
							   	    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2783.875627507198!2d21.222972815567214!3d45.75363927910535!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47455d82fd425403%3A0xebeab37fb452ca7a!2sUniversitatea+Politehnica+Timisoara!5e0!3m2!1sro!2sro!4v1541538244128" width="100%" height="175" frameborder="0" style="border:0" allowfullscreen>
							   	    </iframe>

							   	    <br>
							   	    <small>
							   	    	<a href="https://www.google.com/maps/place/Universitatea+Politehnica+Timisoara/@45.7536393,21.2229728,17z/data=!3m1!4b1!4m5!3m4!1s0x47455d82fd425403:0xebeab37fb452ca7a!8m2!3d45.7536393!4d21.2251615">View Larger Map</a>
							   	    </small>
							  </div>
      				</div>
      			<div class="company_address">
				     	<h2>Company Information</h2>
						    	<p>Adresa: Piaţa Victoriei Nr. 2,</p>
						   		<p>300006 Timişoara, jud. Timiş,</p>
						   		<p>România</p>
				   		<p>Phone: 0256-403000</p>
				   		<p>Fax: 0256-403021</p>
				 	 	<p>Email: <span><a href="mailto:rector@upt.ro">rector@upt.ro</a></span></p>
				   		<p>Follow on: <span><a href="https://www.upt.ro/">UPT</a></span>, <span><a href="https://ro-ro.facebook.com/public/Universitatea-Politehnica-Timisoara-Upt">Facebook</a></span></p>
				   </div>
				 </div>
			  </div>    	
    </div>
 </div>
</div>
  
<?php
	include 'footer.php';
	
<?php
	$conectare = mysqli_connect('localhost', 'root', '', 'shop_pw');
	if(!$conectare)
		die("Conectarea la baza de date nu a reusit!");



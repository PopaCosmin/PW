<?php
	include 'header.php';
?>

	<div class="header_bottom">
		<div class="header_bottom_left">
			<div class="section group">
				<div class="listview_1_of_2 images_1_of_2">
					<div >
						<a href="https://www.samsung.com/global/galaxy/galaxy-watch/"><img src="images/poza_index.jpg" style="width: 300px; height: 160px" / ></a>						
					</div>
				    <!--<div class="text list_2_of_1">
						<h2>Iphone</h2>
						<p>Lorem ipsum dolor sit amet sed do eiusmod.</p>
						<div class="button"><span><a href="preview.php">Add to cart</a></span></div>
				   </div>-->
			   </div>			
				<div class="listview_1_of_2 images_1_of_2">
					<div >
						  <a href="https://consumer.huawei.com/ro/phones/mate20-pro/"><img src="images/poza_index_huawei.jpg" style="width: 300px; height: 160px" / ></a>
					</div>
					<!--<div class="text list_2_of_1">
						  <h2>Samsung</h2>
						  <p>Lorem ipsum dolor sit amet, sed do eiusmod.</p>
						  <div class="button"><span><a href="preview-5.php">Add to cart</a></span></div>
					</div>-->
				</div>
			</div>
			<div class="section group">
				<div class="listview_1_of_2 images_1_of_2">
					<div>
						 <a href="https://www.apple.com/lae/watch/"> <img src="images/apple1.jpg" style="width: 300px; height: 160px" /></a>
					</div>
				    <!--<div class="text list_2_of_1">
						<h2>Acer</h2>
						<p>Lorem ipsum dolor sit amet, sed do eiusmod.</p>
						<div class="button"><span><a href="preview-3.php">Add to cart</a></span></div>
				   </div>-->
			   </div>			
				<div class="listview_1_of_2 images_1_of_2">
					<div >
						  <a href="https://www.apple.com/lae/mac/"><img src="images/apple.jpg" style=" height: 160px" /></a>
					</div>
					<!--<div class="text list_2_of_1">
						  <h2>Canon</h2>
						  <p>Lorem ipsum dolor sit amet, sed do eiusmod.</p>
						  <div class="button"><span><a href="preview-6.php">Add to cart</a></span></div>
					</div>-->
				</div>
			</div>
		  <div class="clear"></div>
		</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
              <section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/pa.jpg" alt=""/></li>
						<li><img src="images/slay.jpg" alt=""/></li>
						<li><img src="images/hy.jpg" alt=""/></li>
						<li><img src="images/xs1.jpg" alt=""/></li>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>	
</div>

  <br>
<?php
	include 'footer.php';


